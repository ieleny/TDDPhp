<?php

namespace Ieleny\casaApostas\Model;

class Usuario
{

    private $usuario;

    public function getUsuario()
    {
        return $this->usuario;
    }

    public function setUsuario($usuario)
    {
        return $this->usuario = $usuario;
    }




}